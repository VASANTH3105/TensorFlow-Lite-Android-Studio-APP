
package com.example.realtime_object

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Researchist : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_researchist)
    }
}